/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphFramework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import GraphFramework.Edge;
import AirFreightApp.*;


/**
 *
 * @author hanee
 */
public class SingleSourceSPAlg extends ShortestPathAlgorithm {
            

    public SingleSourceSPAlg(Graph graph) {
        super(graph);
    }

    
   public void computeDijkstraBasedSPAlg(String sourceStr, int numOfVertices) {

       int infinity = Integer.MAX_VALUE;;
       int numVertices = numOfVertices;
       int source=0;
       
       for(int i=0; i<numVertices; i++){
           if (i >= source){
           if (graph.verList.get(i).label.equals(sourceStr)){
              source=i; 
           }
           
           }
       }
       
      

   
     String sourceLabel = graph.verList.get(source).label;
     int sourceLabelInt = Integer.parseInt(sourceLabel);
        
        
        //intilize array
       int[]  smallestDistance = new int[numVertices];
       String[] path = new String[numVertices];


        //update all the vertices smallestDistance as infinity
        for (int i = 0; i < numVertices; i++) {
            if (i >= source){
            for (int j = 0; j < numVertices; j++)
            smallestDistance[i] = infinity;
            }
        }
            
        System.out.println(smallestDistance.length);
        System.out.println(numVertices);
        
       smallestDistance[source] = 0;

       //smallestDistance[0] = 0;//let the source distancde be zero
      //  path[0] =  ("A --" + smallestDistance[0] + "-->) "; //update it's path twoo
      // path[source] = "A --" + smallestDistance[source] + "--> ";
                path[source] = graph.verList.get(source).label  + " --" + smallestDistance[source] + "--> ";
         
        for (int i = 0; i < numVertices; i++) {
           
            
            if (i >= source)
            { 
             // for(int v=0; v<numVertices; v++){
           // graph.verList.get(v).isVisited = false;
            // } 
            
          
            
            // Find the minium smallestDistance among all the vertices adjacent 
            //----
            //this part act like the PQ to find the smallest distance
                
             int u = 0;
            int minDistance = infinity;
            for (int j = 0; j < numVertices; j++) {
                if (i >= source){
                if (!graph.verList.get(j).isVisited && smallestDistance[j] < minDistance) {
                    minDistance = smallestDistance[j];
                    u = j;
                }
                
                }
            }
            //Once the smallest is found
            graph.verList.get(u).isVisited = true;
            
               //Update the adjacent distances   
            for (int v = 0; v < numVertices; v++) {
                if (i >= source){
                if (!graph.verList.get(v).isVisited && EdgeWeight(u, v) != infinity && EdgeWeight(u, v) != 0) {
                    
                  
                    if (smallestDistance[u] + EdgeWeight(u, v) < smallestDistance[v]) {
                        //update the smallest distance 
                        smallestDistance[v] = smallestDistance[u] + EdgeWeight(u, v);
                        // Update the path too
                        path[v] = path[u] + (char) (v + 65) + " --" + (smallestDistance[v] - smallestDistance[u]) + "--> ";
                    }
                }
                /*
                else if (!graph.verList.get(v).isVisited &&EdgeWeight(u, v) == 0 ){
                   
                     for (int r = 0; r < numVertices; r++){
                        
                     }
                }
               */
                
            }
            }
            
            /*
            int Path=0;
            int SmallestPath=Integer.MAX_VALUE ;
            for(int v = 0; v < numVertices; v++){
                
                if (EdgeWeight(source, v) != Integer.MAX_VALUE && EdgeWeight(source, v) != 0){
                    Path= Path+ EdgeWeight(source, v);
                }
                
                if (Path<SmallestPath){
                   SmallestPath=Path; 
                }
            }
            
            */
         
        }
       
        }
        
      
          
        
          //update all the vertices smallestDistance as infinity
        for (int i = 0; i < numVertices; i++) {
            if (i >= source)
            graph.verList.get(i).isVisited= false;
        }
        
          for (int i = 0; i < numVertices; i++) {
              if (i >= source){
           // System.out.println("---> Shortest Distance from "+ graph.verList(source).label + " to '" + graph.verList(i).label  + "' is " + smallestDistance[i] + ", the Path: " + path[i] + " " + (char) (i + 65) + " " + smallestDistance[i]);
          // int thevertexlabel = graph.verList(source).label;
            String label = graph.verList.get(i).label;
           int LabelInt = Integer.parseInt(label);
          
             System.out.println("---> Shortest Distance from "+ sourceLabelInt+ " to '" + LabelInt  + "' is " + smallestDistance[i] + ", the Path: " + path[i] + " " );
              }
        }
          
                       System.out.println("--------------------------------------------------------------- \n" );
                       
                       
        
   }

    private int EdgeWeight(int u, int v) {
        for (Edge edge : Edge.totalEdges) {
            if (edge.srcVer.label.equals(graph.verList.get(u).label) && edge.destVer.label.equals(graph.verList.get(v).label)) {
                return edge.weight;
            }
        }
        return 0;
    }
   
    
    
    /*
    public void displayResultingMST(int source) {
        System.out.println("single");

        System.out.println("The Starting point location is:");
        System.out.println(graph.verList.get(source));
        // Initialize a list to store the routes
        ArrayList<Route> routes = new ArrayList<>();
        for (Edge edge : Edge.totalEdges) {
            if (edge instanceof Route) {
                routes.add((Route) edge);
            }
        }
        // Sort the routes based on weights
        Collections.sort(routes, Comparator.comparingInt(r -> r.weight));

        Location location = new Location("A", "City");

        for (Route route : routes) {
            System.out.print("loc. " + route.srcVer.getLabel() + ": " + location.getCity());
            System.out.print(" - loc. " + route.destVer.getLabel() + ": " + location.getCity());
            System.out.println(" --- route length " + route.weight);
        }

    } */


}
